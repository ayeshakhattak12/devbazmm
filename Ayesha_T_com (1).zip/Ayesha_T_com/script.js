// Quiz questions data
const quizQuestions = [
    {
        question: "What does HTML stand for?",
        options: [
            "Hyper Text Markup Language",
            "High Tech Modern Language",
            "Hyper Transfer Markup Language",
            "Home Tool Markup Language"
        ],
        correct: 0
    },
    {
        question: "Which of the following is NOT a JavaScript data type?",
        options: [
            "String",
            "Boolean",
            "Float",
            "Undefined"
        ],
        correct: 2
    },
    {
        question: "Which CSS property is used to change the text color?",
        options: [
            "text-color",
            "font-color",
            "color",
            "text-style"
        ],
        correct: 2
    },
    {
        question: "What is the purpose of the 'alt' attribute in an image tag?",
        options: [
            "To add a title to the image",
            "To specify alternative text for the image",
            "To align the image",
            "To add a border to the image"
        ],
        correct: 1
    },
    {
        question: "Which method is used to add an element to the end of an array in JavaScript?",
        options: [
            "push()",
            "append()",
            "addToEnd()",
            "insert()"
        ],
        correct: 0
    },
    {
        question: "What does CSS stand for?",
        options: [
            "Computer Style Sheets",
            "Creative Style System",
            "Cascading Style Sheets",
            "Colorful Style Sheets"
        ],
        correct: 2
    },
    {
        question: "Which HTML tag is used to create a hyperlink?",
        options: [
            "<link>",
            "<a>",
            "<href>",
            "<hyperlink>"
        ],
        correct: 1
    },
    {
        question: "Which of the following is used to declare a variable in JavaScript?",
        options: [
            "var",
            "let",
            "const",
            "All of the above"
        ],
        correct: 3
    }
];

// DOM Elements
const homepage = document.getElementById('homepage');
const quiz = document.getElementById('quiz');
const results = document.getElementById('results');
const startBtn = document.getElementById('start-btn');
const nextBtn = document.getElementById('next-btn');
const submitBtn = document.getElementById('submit-btn');
const restartBtn = document.getElementById('restart-btn');
const questionText = document.getElementById('question-text');
const optionsContainer = document.getElementById('options-container');
const currentQuestion = document.querySelector('.current-question');
const progressBar = document.getElementById('progress-bar');
const timeDisplay = document.getElementById('time');
const finalScore = document.getElementById('final-score');
const resultMessage = document.getElementById('result-message');
const correctAnswersContainer = document.getElementById('correct-answers');

// Quiz state variables
let currentQuestionIndex = 0;
let score = 0;
let userAnswers = [];
let timer;
let timeLeft = 300; // 5 minutes in seconds

// Start the quiz
startBtn.addEventListener('click', startQuiz);

function startQuiz() {
    homepage.style.display = 'none';
    quiz.style.display = 'block';
    results.style.display = 'none';
    
    // Reset quiz state
    currentQuestionIndex = 0;
    score = 0;
    userAnswers = [];
    timeLeft = 300;
    
    // Start timer
    startTimer();
    
    // Load first question
    loadQuestion();
}

// Load a question
function loadQuestion() {
    const question = quizQuestions[currentQuestionIndex];
    
    // Update question counter
    currentQuestion.textContent = `Question ${currentQuestionIndex + 1} of ${quizQuestions.length}`;
    
    // Update progress bar
    progressBar.style.width = `${((currentQuestionIndex + 1) / quizQuestions.length) * 100}%`;
    
    // Set question text
    questionText.textContent = question.question;
    
    // Clear previous options
    optionsContainer.innerHTML = '';
    
    // Add options
    question.options.forEach((option, index) => {
        const optionElement = document.createElement('div');
        optionElement.classList.add('option');
        optionElement.textContent = option;
        
        // Check if this option was previously selected
        if (userAnswers[currentQuestionIndex] === index) {
            optionElement.classList.add('selected');
        }
        
        optionElement.addEventListener('click', () => selectOption(index));
        optionsContainer.appendChild(optionElement);
    });
    
    // Update button visibility
    nextBtn.style.display = currentQuestionIndex < quizQuestions.length - 1 ? 'inline-block' : 'none';
    submitBtn.style.display = currentQuestionIndex === quizQuestions.length - 1 ? 'inline-block' : 'none';
}

// Select an option
function selectOption(optionIndex) {
    // Remove selected class from all options
    const options = document.querySelectorAll('.option');
    options.forEach(option => option.classList.remove('selected'));
    
    // Add selected class to clicked option
    options[optionIndex].classList.add('selected');
    
    // Store user's answer
    userAnswers[currentQuestionIndex] = optionIndex;
}

// Next question
nextBtn.addEventListener('click', () => {
    if (currentQuestionIndex < quizQuestions.length - 1) {
        currentQuestionIndex++;
        loadQuestion();
    }
});

// Submit quiz
submitBtn.addEventListener('click', showResults);

function showResults() {
    // Stop timer
    clearInterval(timer);
    
    // Calculate score
    score = 0;
    quizQuestions.forEach((question, index) => {
        if (userAnswers[index] === question.correct) {
            score++;
        }
    });
    
    // Update results
    finalScore.textContent = `${score}/${quizQuestions.length}`;
    
    // Set result message based on score
    if (score === quizQuestions.length) {
        resultMessage.textContent = "Perfect! You're a coding wizard! 🎉";
    } else if (score >= quizQuestions.length * 0.7) {
        resultMessage.textContent = "Great job! You know your stuff! 👍";
    } else if (score >= quizQuestions.length * 0.5) {
        resultMessage.textContent = "Good effort! Keep learning! 💪";
    } else {
        resultMessage.textContent = "Don't give up! Practice makes perfect! 📚";
    }
    
    // Show correct answers
    correctAnswersContainer.innerHTML = '<h3>Correct Answers:</h3>';
    quizQuestions.forEach((question, index) => {
        const answerDiv = document.createElement('div');
        answerDiv.classList.add('correct-answer');
        
        const questionEl = document.createElement('div');
        questionEl.classList.add('question');
        questionEl.textContent = question.question;
        
        const answerEl = document.createElement('div');
        answerEl.classList.add('answer');
        answerEl.textContent = question.options[question.correct];
        
        answerDiv.appendChild(questionEl);
        answerDiv.appendChild(answerEl);
        correctAnswersContainer.appendChild(answerDiv);
    });
    
    // Show results section
    quiz.style.display = 'none';
    results.style.display = 'block';
}

// Restart quiz
restartBtn.addEventListener('click', startQuiz);

// Timer functionality
function startTimer() {
    updateTimerDisplay();
    
    timer = setInterval(() => {
        timeLeft--;
        updateTimerDisplay();
        
        if (timeLeft <= 0) {
            clearInterval(timer);
            showResults();
        }
    }, 1000);
}

function updateTimerDisplay() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    timeDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    // Change color when time is running out
    if (timeLeft <= 60) {
        timeDisplay.style.color = '#ff5252';
    }
}